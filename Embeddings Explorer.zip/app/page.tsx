import Component from "../embeddings-explorer"

export default function Page() {
  return <Component />
}
